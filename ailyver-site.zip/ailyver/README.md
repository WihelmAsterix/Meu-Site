# AiLyver — Site Institucional

Site institucional oficial da AiLyver, construído como uma experiência digital
premium: dark, com identidade em vermelho neon, animações sutis e foco total
em conversão.

## Stack

- Next.js 15 (App Router, `output: "export"` — site 100% estático)
- React 19
- TypeScript
- Tailwind CSS
- Framer Motion
- Lucide Icons

## Como rodar localmente

```bash
npm install
npm run dev
```

Acesse `http://localhost:3000`.

## Build de produção (estático)

```bash
npm run build
```

O resultado é gerado na pasta `out/`, pronto para ser hospedado em qualquer
serviço de arquivos estáticos (GitHub Pages, Vercel, Netlify, Cloudflare
Pages, etc.).

## Publicação no GitHub Pages

O workflow `.github/workflows/deploy.yml` já está configurado para publicar
automaticamente a cada push na branch `main`:

1. Crie um repositório no GitHub e envie este projeto para ele.
2. Em **Settings → Pages**, defina a origem como **GitHub Actions**.
3. Faça o push para `main` — o workflow builda o projeto e publica em
   `https://<seu-usuario>.github.io/<seu-repositorio>/`.

Se o repositório for do tipo `<usuario>.github.io` (site raiz, sem subpasta),
remova a etapa "Set base path for GitHub Pages" do workflow, pois nesse caso
não é necessário `basePath`.

## Fontes (Google Fonts)

O projeto usa `next/font/google` para carregar **Space Grotesk** (display),
**Inter** (texto) e **JetBrains Mono** (dados/monoespaçada), definidas em
`src/app/layout.tsx`. O Next.js baixa os arquivos de fonte durante o build e
os hospeda junto com o próprio site (sem requisições externas em produção).

Isso exige acesso à internet apenas no momento do `npm run dev` / `npm run
build` (funciona normalmente no seu computador, na Vercel e no GitHub
Actions). Se precisar rodar o build em um ambiente totalmente offline, troque
as importações de `next/font/google` por uma pilha de fontes do sistema em
`src/app/layout.tsx` e remova o `className` de fontes da tag `<html>` — os
fallbacks já estão configurados em `tailwind.config.ts`.

## Configuração central

- `src/config/site.config.ts` — nome, contatos, WhatsApp, redes sociais, SEO
- `src/config/theme.config.ts` — tokens de cor, radius e transições
- `src/config/navigation.config.ts` — links do menu e do rodapé
- `src/config/seo.config.ts` — metadata, Open Graph e schema.org

## Conteúdo editável

Todo o conteúdo textual do site fica em `src/data/`:

- `services.ts`, `pricing.ts`, `gallery.ts` (portfólio), `testimonials.ts`,
  `faq.ts`, `differentials.ts`, `process.ts`

## WhatsApp

O número de WhatsApp usado em todos os botões do site está centralizado em
`src/config/site.config.ts` (`contact.whatsapp`). Atualize-o com o número
real da AiLyver antes de publicar.

## Estrutura de pastas

```text
src/
├── app/            # rotas do App Router (layout, page)
├── components/
│   ├── common/     # Logo, Reveal, WhatsAppFloatingButton, GridGlow
│   ├── layout/      # Navbar, Footer
│   ├── sections/    # Hero, Serviços, Portfólio, Planos, FAQ, Contato...
│   └── ui/          # Button, Card, Accordion, Input, Modal...
├── config/          # configurações centrais do site
├── data/            # conteúdo (serviços, planos, depoimentos, FAQ...)
├── styles/          # globals.css
└── types/           # tipos compartilhados
```
