import { ArrowRight, MessageCircle } from "lucide-react";
import { Container } from "@/components/ui/Container";
import { LinkButton } from "@/components/ui/LinkButton";
import { Reveal } from "@/components/common/Reveal";
import { buildWhatsAppLink } from "@/config/site.config";

export function CTASection() {
  return (
    <section className="relative overflow-hidden py-24 md:py-32">
      <div
        aria-hidden
        className="absolute left-1/2 top-1/2 -z-10 h-[600px] w-[900px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-neon/20 blur-[160px]"
      />
      <Container className="flex flex-col items-center text-center">
        <Reveal>
          <h2 className="max-w-3xl font-display text-3xl font-semibold leading-[1.15] text-mist-100 sm:text-4xl md:text-5xl">
            Pronto para transformar sua presença digital?
          </h2>
        </Reveal>
        <Reveal delay={0.1}>
          <p className="mt-6 max-w-xl text-balance text-base leading-relaxed text-mist-300 md:text-lg">
            Vamos transformar a ideia do seu negócio em uma experiência
            digital profissional.
          </p>
        </Reveal>
        <Reveal delay={0.2} className="mt-10 flex flex-col items-center gap-4 sm:flex-row">
          <LinkButton href="#contato">
            Solicitar orçamento
            <ArrowRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1" />
          </LinkButton>
          <LinkButton
            href={buildWhatsAppLink("Olá! Vim pelo site e quero falar com a AiLyver.")}
            variant="secondary"
            target="_blank"
            rel="noopener noreferrer"
          >
            <MessageCircle className="h-4 w-4" />
            Falar com a AiLyver
          </LinkButton>
        </Reveal>
      </Container>
    </section>
  );
}
