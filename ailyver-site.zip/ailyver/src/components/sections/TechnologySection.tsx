import { BrainCircuit, Rocket, Wand2 } from "lucide-react";
import { Container } from "@/components/ui/Container";
import { Reveal } from "@/components/common/Reveal";

const aiPoints = [
  { icon: Rocket, text: "Acelerar o desenvolvimento sem abrir mão da qualidade." },
  { icon: Wand2, text: "Gerar ideias e otimizar processos criativos e técnicos." },
  { icon: BrainCircuit, text: "Automatizar tarefas repetitivas, liberando tempo para estratégia." },
];

export function TechnologySection() {
  return (
    <section id="tecnologia" className="relative overflow-hidden py-24 md:py-32">
      <div
        aria-hidden
        className="absolute left-1/2 top-1/2 -z-10 h-[500px] w-[500px] -translate-x-1/2 -translate-y-1/2 rounded-full bg-neon/15 blur-[160px]"
      />
      <Container className="grid gap-14 lg:grid-cols-2 lg:items-center">
        <Reveal>
          <span className="text-xs font-semibold uppercase tracking-[0.3em] text-neon-soft">
            Tecnologia &amp; IA
          </span>
          <h2 className="mt-4 font-display text-3xl font-semibold leading-[1.15] text-mist-100 sm:text-4xl md:text-5xl">
            Inteligência Artificial para criar mais.
            <br />
            Desenvolvimento profissional para criar melhor.
          </h2>
          <p className="mt-6 max-w-xl text-base leading-relaxed text-mist-300 md:text-lg">
            A IA não substitui estratégia, design e engenharia — ela potencializa
            a capacidade da nossa equipe. Usamos tecnologia de ponta para entregar
            projetos mais rápidos, mais inteligentes e igualmente sólidos.
          </p>
        </Reveal>

        <div className="flex flex-col gap-5">
          {aiPoints.map((point, index) => (
            <Reveal key={point.text} delay={index * 0.08}>
              <div className="flex items-center gap-5 rounded-xl2 border border-ink-600 bg-ink-800/50 p-6 backdrop-blur-sm">
                <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full border border-neon/30 bg-neon/10">
                  <point.icon className="h-5 w-5 text-neon" />
                </div>
                <p className="text-sm leading-relaxed text-mist-200 md:text-base">
                  {point.text}
                </p>
              </div>
            </Reveal>
          ))}
        </div>
      </Container>
    </section>
  );
}
