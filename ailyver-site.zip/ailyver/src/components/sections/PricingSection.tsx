import { Check } from "lucide-react";
import { Container } from "@/components/ui/Container";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { LinkButton } from "@/components/ui/LinkButton";
import { Reveal } from "@/components/common/Reveal";
import { cn } from "@/lib/utils";
import { pricingPlans } from "@/data/pricing";

export function PricingSection() {
  return (
    <section id="planos" className="relative py-24 md:py-32">
      <Container>
        <Reveal>
          <SectionHeading
            eyebrow="Planos"
            title="Um plano para cada estágio do seu negócio."
            description="Valores de referência — todo projeto pode ser ajustado conforme o escopo e as necessidades da sua empresa."
          />
        </Reveal>

        <div className="mt-16 grid grid-cols-1 gap-6 lg:grid-cols-3">
          {pricingPlans.map((plan, index) => (
            <Reveal key={plan.id} delay={index * 0.08}>
              <div
                className={cn(
                  "relative flex h-full flex-col rounded-xl2 border p-8",
                  plan.featured
                    ? "border-neon/50 bg-gradient-to-b from-neon/10 to-ink-900 shadow-neon"
                    : "border-ink-600 bg-ink-800/40"
                )}
              >
                {plan.featured ? (
                  <span className="absolute -top-3 left-8 rounded-full bg-neon px-4 py-1 text-xs font-semibold text-white shadow-neon-sm">
                    Mais escolhido
                  </span>
                ) : null}
                <h3 className="font-display text-xl font-semibold text-mist-100">
                  {plan.name}
                </h3>
                <p className="mt-2 text-sm leading-relaxed text-mist-300">
                  {plan.tagline}
                </p>
                <div className="mt-6">
                  <span className="font-display text-3xl font-semibold text-mist-100">
                    {plan.price}
                  </span>
                  <span className="ml-2 text-xs text-mist-400">{plan.priceNote}</span>
                </div>

                <ul className="mt-8 flex flex-1 flex-col gap-3">
                  {plan.features.map((feature) => (
                    <li key={feature} className="flex items-start gap-3 text-sm text-mist-300">
                      <Check className="mt-0.5 h-4 w-4 shrink-0 text-neon" />
                      {feature}
                    </li>
                  ))}
                </ul>

                <LinkButton
                  href="#contato"
                  variant={plan.featured ? "primary" : "secondary"}
                  className="mt-8 w-full"
                >
                  Solicitar orçamento
                </LinkButton>
              </div>
            </Reveal>
          ))}
        </div>
      </Container>
    </section>
  );
}
