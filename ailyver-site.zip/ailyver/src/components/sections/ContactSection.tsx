"use client";

import { MessageCircle, Send } from "lucide-react";
import { useState } from "react";
import type { FormEvent } from "react";
import { Container } from "@/components/ui/Container";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { Input } from "@/components/ui/Input";
import { Textarea } from "@/components/ui/Textarea";
import { Button } from "@/components/ui/Button";
import { LinkButton } from "@/components/ui/LinkButton";
import { Reveal } from "@/components/common/Reveal";
import { buildWhatsAppLink, siteConfig } from "@/config/site.config";

type FormState = {
  name: string;
  company: string;
  segment: string;
  whatsapp: string;
  email: string;
  service: string;
  budget: string;
  message: string;
};

const initialState: FormState = {
  name: "",
  company: "",
  segment: "",
  whatsapp: "",
  email: "",
  service: "",
  budget: "",
  message: "",
};

function buildSummary(data: FormState) {
  return [
    "Olá! Vim pelo site da AiLyver e gostaria de solicitar um orçamento.",
    "",
    `Nome: ${data.name}`,
    `Empresa: ${data.company}`,
    `Segmento: ${data.segment}`,
    `E-mail: ${data.email}`,
    `Serviço desejado: ${data.service}`,
    `Orçamento aproximado: ${data.budget}`,
    data.message ? `Mensagem: ${data.message}` : null,
  ]
    .filter(Boolean)
    .join("\n");
}

export function ContactSection() {
  const [form, setForm] = useState<FormState>(initialState);
  const [sent, setSent] = useState(false);

  function handleChange(field: keyof FormState) {
    return (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
      setForm((prev) => ({ ...prev, [field]: e.target.value }));
    };
  }

  function handleSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const link = buildWhatsAppLink(buildSummary(form));
    setSent(true);
    window.open(link, "_blank", "noopener,noreferrer");
  }

  return (
    <section id="contato" className="relative py-24 md:py-32">
      <Container className="grid gap-16 lg:grid-cols-[1fr_1.2fr]">
        <Reveal>
          <SectionHeading
            eyebrow="Contato"
            title="Vamos conversar sobre o seu projeto."
            description="Preencha o formulário ao lado ou fale diretamente com a nossa equipe pelo WhatsApp."
            align="left"
          />

          <div className="mt-10 flex flex-col gap-4 text-sm text-mist-300">
            <p>
              <span className="text-mist-400">E-mail: </span>
              <a
                href={`mailto:${siteConfig.contact.email}`}
                className="text-mist-100 hover:text-neon"
              >
                {siteConfig.contact.email}
              </a>
            </p>
            <p>
              <span className="text-mist-400">WhatsApp: </span>
              <span className="text-mist-100">{siteConfig.contact.whatsappDisplay}</span>
            </p>
            <p>
              <span className="text-mist-400">Atendimento: </span>
              <span className="text-mist-100">{siteConfig.contact.address}</span>
            </p>
          </div>

          <LinkButton
            href={buildWhatsAppLink("Olá! Vim pelo site e quero falar com a AiLyver.")}
            target="_blank"
            rel="noopener noreferrer"
            variant="secondary"
            className="mt-8"
          >
            <MessageCircle className="h-4 w-4" />
            Falar pelo WhatsApp
          </LinkButton>
        </Reveal>

        <Reveal delay={0.1}>
          <form
            onSubmit={handleSubmit}
            className="flex flex-col gap-5 rounded-xl2 border border-ink-600 bg-ink-800/40 p-8"
          >
            <div className="grid gap-5 sm:grid-cols-2">
              <Input
                label="Nome"
                name="name"
                required
                value={form.name}
                onChange={handleChange("name")}
                placeholder="Seu nome completo"
              />
              <Input
                label="Empresa"
                name="company"
                required
                value={form.company}
                onChange={handleChange("company")}
                placeholder="Nome do seu negócio"
              />
            </div>
            <div className="grid gap-5 sm:grid-cols-2">
              <Input
                label="Segmento"
                name="segment"
                required
                value={form.segment}
                onChange={handleChange("segment")}
                placeholder="Ex: Restaurante, clínica..."
              />
              <Input
                label="WhatsApp"
                name="whatsapp"
                required
                value={form.whatsapp}
                onChange={handleChange("whatsapp")}
                placeholder="(11) 99999-9999"
              />
            </div>
            <Input
              label="E-mail"
              type="email"
              name="email"
              required
              value={form.email}
              onChange={handleChange("email")}
              placeholder="voce@empresa.com"
            />
            <div className="grid gap-5 sm:grid-cols-2">
              <Input
                label="Serviço desejado"
                name="service"
                required
                value={form.service}
                onChange={handleChange("service")}
                placeholder="Ex: Site institucional"
              />
              <Input
                label="Orçamento aproximado"
                name="budget"
                value={form.budget}
                onChange={handleChange("budget")}
                placeholder="Opcional"
              />
            </div>
            <Textarea
              label="Mensagem"
              name="message"
              value={form.message}
              onChange={handleChange("message")}
              placeholder="Conte um pouco sobre o seu projeto"
            />

            <Button type="submit" className="mt-2 w-full sm:w-fit">
              Enviar solicitação
              <Send className="h-4 w-4" />
            </Button>

            {sent ? (
              <p className="text-sm text-neon-soft">
                Abrimos o WhatsApp com sua solicitação preenchida — é só enviar por lá!
              </p>
            ) : null}
          </form>
        </Reveal>
      </Container>
    </section>
  );
}
