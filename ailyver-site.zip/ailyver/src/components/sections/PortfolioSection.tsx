import { ArrowUpRight } from "lucide-react";
import { Container } from "@/components/ui/Container";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { Reveal } from "@/components/common/Reveal";
import { portfolioProjects } from "@/data/gallery";

export function PortfolioSection() {
  return (
    <section id="projetos" className="relative py-24 md:py-32">
      <Container>
        <Reveal>
          <SectionHeading
            eyebrow="Projetos"
            title="Cases que mostram como transformamos negócios locais."
            description="Projetos demonstrativos que representam o padrão de qualidade e o cuidado que aplicamos a cada cliente."
          />
        </Reveal>

        <div className="mt-16 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {portfolioProjects.map((project, index) => (
            <Reveal key={project.id} delay={index * 0.05}>
              <article className="group relative flex h-full flex-col overflow-hidden rounded-xl2 border border-ink-600 bg-ink-800/40">
                <div
                  className={`relative flex h-40 items-center justify-center bg-gradient-to-br ${project.accent} via-ink-900 to-ink-900`}
                >
                  <span className="font-display text-2xl font-semibold text-mist-100/90">
                    {project.name}
                  </span>
                  <div className="absolute inset-0 bg-grid-fade opacity-40" />
                </div>
                <div className="flex flex-1 flex-col gap-4 p-7">
                  <span className="text-xs font-semibold uppercase tracking-[0.2em] text-neon-soft">
                    {project.segment}
                  </span>
                  <p className="text-sm leading-relaxed text-mist-300">
                    {project.description}
                  </p>
                  <div className="flex flex-wrap gap-2">
                    {project.technologies.map((tech) => (
                      <span
                        key={tech}
                        className="rounded-full border border-ink-600 px-3 py-1 text-xs text-mist-400"
                      >
                        {tech}
                      </span>
                    ))}
                  </div>
                  <p className="mt-1 text-xs font-medium text-mist-200">
                    {project.result}
                  </p>
                  <button className="mt-auto flex w-fit items-center gap-1.5 text-sm font-semibold text-neon-soft transition-colors hover:text-neon">
                    Ver projeto
                    <ArrowUpRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
                  </button>
                </div>
              </article>
            </Reveal>
          ))}
        </div>
      </Container>
    </section>
  );
}
