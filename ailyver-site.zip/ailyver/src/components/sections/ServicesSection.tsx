import { Container } from "@/components/ui/Container";
import { Card } from "@/components/ui/Card";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { Reveal } from "@/components/common/Reveal";
import { services } from "@/data/services";

export function ServicesSection() {
  return (
    <section className="relative py-24 md:py-32">
      <Container>
        <Reveal>
          <SectionHeading
            eyebrow="Soluções"
            title="Um ecossistema completo de presença digital."
            description="Da concepção à evolução contínua, a AiLyver acompanha cada etapa da sua jornada digital."
          />
        </Reveal>

        <div className="mt-16 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {services.map((service, index) => (
            <Reveal key={service.id} delay={index * 0.05}>
              <Card className="h-full">
                <div className="flex h-11 w-11 items-center justify-center rounded-full border border-neon/30 bg-neon/10">
                  <service.icon className="h-5 w-5 text-neon" />
                </div>
                <h3 className="mt-5 font-display text-lg font-semibold text-mist-100">
                  {service.title}
                </h3>
                <p className="mt-3 text-sm leading-relaxed text-mist-300">
                  {service.description}
                </p>
                <ul className="mt-5 flex flex-wrap gap-2">
                  {service.highlights.map((highlight) => (
                    <li
                      key={highlight}
                      className="rounded-full border border-ink-600 px-3 py-1 text-xs text-mist-400"
                    >
                      {highlight}
                    </li>
                  ))}
                </ul>
              </Card>
            </Reveal>
          ))}
        </div>
      </Container>
    </section>
  );
}
