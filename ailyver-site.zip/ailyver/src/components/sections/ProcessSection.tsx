import { Container } from "@/components/ui/Container";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { Reveal } from "@/components/common/Reveal";
import { processSteps } from "@/data/process";

export function ProcessSection() {
  return (
    <section id="processo" className="relative py-24 md:py-32">
      <Container>
        <Reveal>
          <SectionHeading
            eyebrow="Processo"
            title="Um método claro, do briefing ao lançamento — e além."
            description="Cada etapa existe por um motivo. Transparência total sobre como o seu projeto é construído."
          />
        </Reveal>

        <div className="relative mt-16">
          <div
            aria-hidden
            className="absolute left-[27px] top-2 hidden h-[calc(100%-2rem)] w-px bg-gradient-to-b from-neon/60 via-ink-600 to-transparent md:block"
          />
          <div className="flex flex-col gap-3">
            {processSteps.map((step, index) => (
              <Reveal key={step.number} delay={index * 0.06}>
                <div className="group flex items-start gap-6 rounded-xl2 border border-transparent p-4 transition-colors duration-300 hover:border-ink-600 hover:bg-ink-800/40 md:p-6">
                  <span className="relative z-10 flex h-14 w-14 shrink-0 items-center justify-center rounded-full border border-neon/30 bg-ink-900 font-display text-sm font-semibold text-neon-soft">
                    {step.number}
                  </span>
                  <div className="pt-2">
                    <h3 className="font-display text-lg font-semibold text-mist-100">
                      {step.title}
                    </h3>
                    <p className="mt-2 max-w-2xl text-sm leading-relaxed text-mist-300 md:text-base">
                      {step.description}
                    </p>
                  </div>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </Container>
    </section>
  );
}
