import { Cpu, Gauge, LayoutTemplate, Search, ShieldCheck, Smartphone } from "lucide-react";
import { Container } from "@/components/ui/Container";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { Reveal } from "@/components/common/Reveal";

const pillars = [
  { icon: LayoutTemplate, title: "Design personalizado", description: "Uma experiência criada para a identidade real do seu negócio." },
  { icon: Cpu, title: "Desenvolvimento profissional", description: "Código sólido, escalável e sustentado por boas práticas." },
  { icon: Smartphone, title: "UX/UI", description: "Navegação intuitiva pensada para conversão em qualquer tela." },
  { icon: Search, title: "SEO", description: "Estrutura técnica que ajuda o seu negócio a ser encontrado." },
  { icon: Gauge, title: "Performance", description: "Carregamento rápido, sem fricção entre o clique e o resultado." },
  { icon: ShieldCheck, title: "Suporte contínuo", description: "Manutenção e evolução constante após o site entrar no ar." },
];

export function SolutionSection() {
  return (
    <section id="solucoes" className="relative py-24 md:py-32">
      <Container>
        <Reveal>
          <SectionHeading
            eyebrow="A solução"
            title="Mais do que um site. Uma experiência digital criada para o seu negócio."
            description="Unimos estratégia, design e tecnologia para transformar sua presença online em uma ferramenta real de crescimento."
          />
        </Reveal>

        <div className="mt-16 grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {pillars.map((pillar, index) => (
            <Reveal key={pillar.title} delay={index * 0.06}>
              <div className="flex h-full flex-col gap-4 rounded-xl2 border border-ink-600 bg-gradient-to-b from-ink-800/60 to-ink-900/40 p-7">
                <div className="flex h-11 w-11 items-center justify-center rounded-full border border-neon/30 bg-neon/10">
                  <pillar.icon className="h-5 w-5 text-neon" />
                </div>
                <h3 className="font-display text-lg font-semibold text-mist-100">
                  {pillar.title}
                </h3>
                <p className="text-sm leading-relaxed text-mist-300">
                  {pillar.description}
                </p>
              </div>
            </Reveal>
          ))}
        </div>
      </Container>
    </section>
  );
}
