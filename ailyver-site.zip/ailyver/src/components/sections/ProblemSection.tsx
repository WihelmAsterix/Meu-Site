import {
  AlertTriangle,
  Clock,
  Frown,
  MapPin,
  MessageSquareOff,
  Smartphone,
  TrendingDown,
  ZapOff,
} from "lucide-react";
import { Container } from "@/components/ui/Container";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { Reveal } from "@/components/common/Reveal";

const problems = [
  { icon: Clock, text: "Site desatualizado, que não representa o negócio hoje." },
  { icon: Frown, text: "Aparência pouco profissional diante da concorrência." },
  { icon: AlertTriangle, text: "Falta de credibilidade na primeira impressão." },
  { icon: ZapOff, text: "Site lento, que afasta o visitante em segundos." },
  { icon: Smartphone, text: "Experiência ruim no celular, onde estão os clientes." },
  { icon: MessageSquareOff, text: "Sem integração direta com o WhatsApp." },
  { icon: MapPin, text: "Dificuldade para ser encontrado no Google." },
  { icon: TrendingDown, text: "Nenhuma geração real de leads e oportunidades." },
];

export function ProblemSection() {
  return (
    <section className="relative py-24 md:py-32">
      <Container>
        <Reveal>
          <SectionHeading
            eyebrow="O problema"
            title="Presença digital fraca custa clientes todos os dias."
            description="Enquanto o seu site não transmite profissionalismo, a concorrência está conquistando o cliente que deveria ser seu."
          />
        </Reveal>

        <div className="mt-16 grid grid-cols-1 gap-px overflow-hidden rounded-xl2 border border-ink-600 bg-ink-600 sm:grid-cols-2 lg:grid-cols-4">
          {problems.map((problem, index) => (
            <Reveal key={problem.text} delay={index * 0.05}>
              <div className="flex h-full flex-col gap-4 bg-ink-900 p-7 transition-colors duration-300 hover:bg-ink-800">
                <problem.icon className="h-5 w-5 text-neon" />
                <p className="text-sm leading-relaxed text-mist-300">{problem.text}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </Container>
    </section>
  );
}
