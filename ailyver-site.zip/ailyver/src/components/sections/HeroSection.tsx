"use client";

import { motion } from "framer-motion";
import { ArrowRight, Sparkles } from "lucide-react";
import { Container } from "@/components/ui/Container";
import { LinkButton } from "@/components/ui/LinkButton";
import { GridGlow } from "@/components/common/GridGlow";

const orbitItems = [
  { label: "UX/UI", top: "12%", left: "6%", delay: 0 },
  { label: "SEO técnico", top: "68%", left: "2%", delay: 0.6 },
  { label: "Performance 95+", top: "8%", left: "78%", delay: 0.3 },
  { label: "IA aplicada", top: "72%", left: "80%", delay: 0.9 },
];

export function HeroSection() {
  return (
    <section
      id="inicio"
      className="relative flex min-h-screen items-center overflow-hidden pt-32 pb-20"
    >
      <GridGlow />
      <div
        aria-hidden
        className="absolute left-1/2 top-[-10%] -z-10 h-[560px] w-[560px] -translate-x-1/2 rounded-full bg-neon/25 blur-[140px]"
      />

      {orbitItems.map((item) => (
        <motion.span
          key={item.label}
          className="pointer-events-none absolute hidden select-none rounded-full border border-neon/25 bg-ink-900/70 px-4 py-2 text-xs font-medium text-mist-300 backdrop-blur md:block"
          style={{ top: item.top, left: item.left }}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: item.delay }}
        >
          <span className="mr-2 inline-block h-1.5 w-1.5 rounded-full bg-neon" />
          {item.label}
        </motion.span>
      ))}

      <Container className="relative flex flex-col items-center text-center">
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="mb-8 inline-flex items-center gap-2 rounded-full border border-neon/30 bg-neon/5 px-4 py-1.5 text-xs font-medium uppercase tracking-[0.2em] text-neon-soft"
        >
          <Sparkles className="h-3.5 w-3.5" />
          Agência digital com IA aplicada
        </motion.div>

        <motion.h1
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.1 }}
          className="max-w-4xl font-display text-4xl font-semibold leading-[1.08] text-mist-100 sm:text-5xl md:text-7xl"
        >
          Seu negócio merece uma{" "}
          <span className="relative whitespace-nowrap text-neon">
            presença digital
            <span className="absolute -inset-x-2 -inset-y-1 -z-10 rounded-2xl bg-neon/10 blur-2xl" />
          </span>{" "}
          extraordinária.
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.2 }}
          className="mt-7 max-w-2xl text-balance text-base leading-relaxed text-mist-300 md:text-lg"
        >
          Criamos sites, experiências digitais e soluções inteligentes que
          transformam negócios locais em marcas profissionais na internet.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.3 }}
          className="mt-10 flex flex-col items-center gap-4 sm:flex-row"
        >
          <LinkButton href="#contato">
            Quero transformar meu negócio
            <ArrowRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1" />
          </LinkButton>
          <LinkButton href="#projetos" variant="secondary">
            Ver projetos
          </LinkButton>
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.8, delay: 0.5 }}
          className="mt-20 flex w-full max-w-3xl flex-wrap items-center justify-center gap-x-10 gap-y-4 border-t border-ink-600 pt-8 text-xs font-medium uppercase tracking-[0.2em] text-mist-400"
        >
          <span>Next.js 15</span>
          <span className="h-1 w-1 rounded-full bg-ink-600" />
          <span>React 19</span>
          <span className="h-1 w-1 rounded-full bg-ink-600" />
          <span>Design Systems</span>
          <span className="h-1 w-1 rounded-full bg-ink-600" />
          <span>SEO Técnico</span>
          <span className="h-1 w-1 rounded-full bg-ink-600" />
          <span>Inteligência Artificial</span>
        </motion.div>
      </Container>
    </section>
  );
}
