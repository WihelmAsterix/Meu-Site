import { Container } from "@/components/ui/Container";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { Reveal } from "@/components/common/Reveal";
import { differentials } from "@/data/differentials";

export function DifferentialsSection() {
  return (
    <section id="diferenciais" className="relative py-24 md:py-32">
      <div
        aria-hidden
        className="absolute inset-x-0 top-0 -z-10 h-px bg-gradient-to-r from-transparent via-neon/40 to-transparent"
      />
      <Container>
        <Reveal>
          <SectionHeading
            eyebrow="Diferenciais"
            title="Por que empresas escolhem a AiLyver."
            description="Cada projeto combina tecnologia, design e estratégia para gerar resultado real — não apenas um site bonito."
          />
        </Reveal>

        <div className="mt-16 grid grid-cols-1 divide-y divide-ink-600 rounded-xl2 border border-ink-600 bg-ink-900/40 sm:grid-cols-3 sm:divide-x sm:divide-y-0">
          {differentials.map((item, index) => (
            <Reveal key={item.title} delay={index * 0.04} className="h-full">
              <div className="flex h-full flex-col gap-3 p-8">
                <item.icon className="h-5 w-5 text-neon" />
                <h3 className="font-display text-base font-semibold text-mist-100">
                  {item.title}
                </h3>
                <p className="text-sm leading-relaxed text-mist-300">
                  {item.description}
                </p>
              </div>
            </Reveal>
          ))}
        </div>
      </Container>
    </section>
  );
}
