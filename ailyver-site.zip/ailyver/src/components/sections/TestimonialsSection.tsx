import { Quote } from "lucide-react";
import { Container } from "@/components/ui/Container";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { Reveal } from "@/components/common/Reveal";
import { testimonials } from "@/data/testimonials";

export function TestimonialsSection() {
  return (
    <section className="relative py-24 md:py-32">
      <Container>
        <Reveal>
          <SectionHeading
            eyebrow="Depoimentos"
            title="Exemplos de como um projeto AiLyver pode soar na voz do cliente."
            description="Depoimentos demonstrativos, com estrutura pronta para receber relatos reais conforme a carteira de clientes cresce."
          />
        </Reveal>

        <div className="mt-16 grid grid-cols-1 gap-6 md:grid-cols-2">
          {testimonials.map((testimonial, index) => (
            <Reveal key={testimonial.id} delay={index * 0.06}>
              <div className="flex h-full flex-col gap-5 rounded-xl2 border border-ink-600 bg-ink-800/40 p-8">
                <Quote className="h-6 w-6 text-neon/60" />
                <p className="flex-1 text-sm leading-relaxed text-mist-200 md:text-base">
                  &ldquo;{testimonial.quote}&rdquo;
                </p>
                <div className="flex items-center gap-3 border-t border-ink-600 pt-5">
                  <div className="flex h-10 w-10 items-center justify-center rounded-full bg-neon/10 font-display text-sm font-semibold text-neon-soft">
                    {testimonial.name.charAt(0)}
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-mist-100">
                      {testimonial.name}
                    </p>
                    <p className="text-xs text-mist-400">
                      {testimonial.role} · {testimonial.company}
                    </p>
                  </div>
                </div>
              </div>
            </Reveal>
          ))}
        </div>
      </Container>
    </section>
  );
}
