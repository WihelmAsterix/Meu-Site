import { Database, LifeBuoy, Lock, RefreshCcw, Server, Search } from "lucide-react";
import { Container } from "@/components/ui/Container";
import { Reveal } from "@/components/common/Reveal";

const recurringServices = [
  { icon: Server, title: "Hospedagem" },
  { icon: RefreshCcw, title: "Atualizações" },
  { icon: Lock, title: "Segurança" },
  { icon: Database, title: "Backup" },
  { icon: Search, title: "SEO contínuo" },
  { icon: LifeBuoy, title: "Suporte" },
];

export function RecurringSection() {
  return (
    <section className="relative py-24 md:py-32">
      <Container className="grid gap-12 lg:grid-cols-2 lg:items-center">
        <Reveal>
          <span className="text-xs font-semibold uppercase tracking-[0.3em] text-neon-soft">
            Relacionamento contínuo
          </span>
          <h2 className="mt-4 font-display text-3xl font-semibold leading-[1.15] text-mist-100 sm:text-4xl md:text-5xl">
            Seu projeto não termina quando o site entra no ar.
          </h2>
          <p className="mt-6 max-w-xl text-base leading-relaxed text-mist-300 md:text-lg">
            Seu negócio muda. Seu site também deve evoluir. Por isso, mantemos
            um relacionamento contínuo depois do lançamento — cuidando da
            hospedagem, da segurança e da evolução do seu projeto.
          </p>
        </Reveal>

        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3">
          {recurringServices.map((item, index) => (
            <Reveal key={item.title} delay={index * 0.05}>
              <div className="flex flex-col items-center gap-3 rounded-xl2 border border-ink-600 bg-ink-800/40 p-6 text-center">
                <item.icon className="h-5 w-5 text-neon" />
                <span className="text-sm font-medium text-mist-200">{item.title}</span>
              </div>
            </Reveal>
          ))}
        </div>
      </Container>
    </section>
  );
}
