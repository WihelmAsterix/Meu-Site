import { Container } from "@/components/ui/Container";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { Accordion } from "@/components/ui/Accordion";
import { Reveal } from "@/components/common/Reveal";
import { faqItems } from "@/data/faq";

export function FAQSection() {
  return (
    <section id="faq" className="relative py-24 md:py-32">
      <Container className="mx-auto max-w-3xl">
        <Reveal>
          <SectionHeading
            eyebrow="FAQ"
            title="Perguntas frequentes"
            description="Reunimos as dúvidas mais comuns de quem está pensando em transformar sua presença digital."
          />
        </Reveal>

        <Reveal delay={0.1} className="mt-14">
          <Accordion items={faqItems} />
        </Reveal>
      </Container>
    </section>
  );
}
