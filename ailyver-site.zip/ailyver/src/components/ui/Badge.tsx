import { cn } from "@/lib/utils";
import type { HTMLAttributes } from "react";

export function Badge({
  className,
  children,
  ...props
}: HTMLAttributes<HTMLSpanElement>) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-2 rounded-full border border-neon/30 bg-neon/5 px-4 py-1.5 text-[0.7rem] font-medium uppercase tracking-[0.2em] text-neon-soft",
        className
      )}
      {...props}
    >
      <span className="h-1.5 w-1.5 rounded-full bg-neon shadow-neon-sm" />
      {children}
    </span>
  );
}
