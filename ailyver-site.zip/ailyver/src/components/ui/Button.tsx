import { cn } from "@/lib/utils";
import type { ButtonHTMLAttributes } from "react";

type ButtonVariant = "primary" | "secondary" | "ghost";

export function Button({
  className,
  variant = "primary",
  children,
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & { variant?: ButtonVariant }) {
  return (
    <button className={cn(baseClasses, variantClasses[variant], className)} {...props}>
      {children}
    </button>
  );
}

const baseClasses =
  "group relative inline-flex items-center justify-center gap-2 rounded-full px-7 py-3.5 text-sm font-semibold tracking-wide transition-all duration-300 ease-out focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-neon focus-visible:ring-offset-2 focus-visible:ring-offset-ink-900 disabled:cursor-not-allowed disabled:opacity-50";

const variantClasses: Record<ButtonVariant, string> = {
  primary:
    "bg-neon text-white shadow-neon hover:bg-neon-soft hover:shadow-[0_0_0_1px_rgba(255,11,62,0.5),0_0_36px_rgba(255,11,62,0.5)] active:scale-[0.98]",
  secondary:
    "border border-ink-600 bg-ink-800/60 text-mist-100 backdrop-blur hover:border-neon/50 hover:text-white active:scale-[0.98]",
  ghost:
    "text-mist-200 hover:text-white",
};
