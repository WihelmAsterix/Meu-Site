import { cn } from "@/lib/utils";
import type { HTMLAttributes } from "react";

export function Card({ className, children, ...props }: HTMLAttributes<HTMLDivElement>) {
  return (
    <div
      className={cn(
        "group relative overflow-hidden rounded-xl2 border border-ink-600 bg-ink-800/50 p-8 shadow-card backdrop-blur-sm transition-all duration-500 hover:border-neon/40 hover:bg-ink-800/80",
        className
      )}
      {...props}
    >
      <div className="pointer-events-none absolute -inset-px rounded-xl2 opacity-0 transition-opacity duration-500 group-hover:opacity-100 bg-radial-glow" />
      <div className="relative z-10">{children}</div>
    </div>
  );
}
