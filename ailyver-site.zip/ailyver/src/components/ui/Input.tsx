import { cn } from "@/lib/utils";
import type { InputHTMLAttributes } from "react";

type InputProps = InputHTMLAttributes<HTMLInputElement> & { label: string };

export function Input({ label, id, className, ...props }: InputProps) {
  const inputId = id ?? props.name;
  return (
    <label htmlFor={inputId} className="flex flex-col gap-2 text-left">
      <span className="text-xs font-medium uppercase tracking-wider text-mist-300">
        {label}
      </span>
      <input
        id={inputId}
        className={cn(
          "rounded-lg border border-ink-600 bg-ink-900/70 px-4 py-3 text-sm text-mist-100 placeholder:text-mist-400/70 transition-colors duration-200 focus:border-neon focus:outline-none focus:ring-1 focus:ring-neon",
          className
        )}
        {...props}
      />
    </label>
  );
}
