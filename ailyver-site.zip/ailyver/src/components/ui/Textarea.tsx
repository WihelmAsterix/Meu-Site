import { cn } from "@/lib/utils";
import type { TextareaHTMLAttributes } from "react";

type TextareaProps = TextareaHTMLAttributes<HTMLTextAreaElement> & { label: string };

export function Textarea({ label, id, className, ...props }: TextareaProps) {
  const areaId = id ?? props.name;
  return (
    <label htmlFor={areaId} className="flex flex-col gap-2 text-left">
      <span className="text-xs font-medium uppercase tracking-wider text-mist-300">
        {label}
      </span>
      <textarea
        id={areaId}
        rows={5}
        className={cn(
          "resize-none rounded-lg border border-ink-600 bg-ink-900/70 px-4 py-3 text-sm text-mist-100 placeholder:text-mist-400/70 transition-colors duration-200 focus:border-neon focus:outline-none focus:ring-1 focus:ring-neon",
          className
        )}
        {...props}
      />
    </label>
  );
}
