import { cn } from "@/lib/utils";

export function Logo({ className }: { className?: string }) {
  return (
    <span
      className={cn(
        "font-display text-xl font-bold tracking-tight text-mist-100",
        className
      )}
    >
      <span className="text-neon">Ai</span>Lyver
    </span>
  );
}
