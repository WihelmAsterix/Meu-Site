"use client";

import { MessageCircle } from "lucide-react";
import { buildWhatsAppLink } from "@/config/site.config";

export function WhatsAppFloatingButton() {
  return (
    <a
      href={buildWhatsAppLink("Olá! Vim pelo site e quero saber mais sobre a AiLyver.")}
      target="_blank"
      rel="noopener noreferrer"
      aria-label="Falar no WhatsApp"
      className="fixed bottom-6 right-6 z-50 flex h-14 w-14 items-center justify-center rounded-full bg-neon text-white shadow-neon transition-transform duration-300 hover:scale-105 md:bottom-8 md:right-8"
    >
      <MessageCircle className="h-6 w-6" />
      <span className="absolute inset-0 -z-10 animate-pulse-glow rounded-full bg-neon/40 blur-xl" />
    </a>
  );
}
