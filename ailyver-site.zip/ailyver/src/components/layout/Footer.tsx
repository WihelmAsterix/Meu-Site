import { Instagram, Linkedin, Mail } from "lucide-react";
import { Logo } from "@/components/common/Logo";
import { Container } from "@/components/ui/Container";
import { footerNav } from "@/config/navigation.config";
import { siteConfig } from "@/config/site.config";

export function Footer() {
  const year = new Date().getFullYear();

  return (
    <footer className="relative border-t border-ink-600 bg-ink-950">
      <Container className="py-16">
        <div className="grid gap-12 lg:grid-cols-[1.4fr_1fr_1fr_1fr]">
          <div className="flex flex-col gap-4">
            <Logo />
            <p className="max-w-xs text-sm leading-relaxed text-mist-400">
              {siteConfig.description}
            </p>
            <div className="mt-2 flex items-center gap-3">
              <a
                href={siteConfig.contact.instagram}
                target="_blank"
                rel="noopener noreferrer"
                aria-label="Instagram da AiLyver"
                className="flex h-9 w-9 items-center justify-center rounded-full border border-ink-600 text-mist-300 transition-colors hover:border-neon/50 hover:text-neon"
              >
                <Instagram className="h-4 w-4" />
              </a>
              <a
                href={siteConfig.contact.linkedin}
                target="_blank"
                rel="noopener noreferrer"
                aria-label="LinkedIn da AiLyver"
                className="flex h-9 w-9 items-center justify-center rounded-full border border-ink-600 text-mist-300 transition-colors hover:border-neon/50 hover:text-neon"
              >
                <Linkedin className="h-4 w-4" />
              </a>
              <a
                href={`mailto:${siteConfig.contact.email}`}
                aria-label="E-mail da AiLyver"
                className="flex h-9 w-9 items-center justify-center rounded-full border border-ink-600 text-mist-300 transition-colors hover:border-neon/50 hover:text-neon"
              >
                <Mail className="h-4 w-4" />
              </a>
            </div>
          </div>

          {footerNav.map((group) => (
            <div key={group.title} className="flex flex-col gap-4">
              <h4 className="text-xs font-semibold uppercase tracking-[0.2em] text-mist-400">
                {group.title}
              </h4>
              <ul className="flex flex-col gap-3">
                {group.links.map((link) => (
                  <li key={link.href}>
                    <a
                      href={link.href}
                      className="text-sm text-mist-300 transition-colors hover:text-white"
                    >
                      {link.label}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="mt-14 flex flex-col items-center justify-between gap-4 border-t border-ink-600 pt-8 text-xs text-mist-400 sm:flex-row">
          <p>
            &copy; {year} {siteConfig.name}. Todos os direitos reservados.
          </p>
          <p>CNPJ sob consulta · Atendimento remoto para todo o Brasil</p>
        </div>
      </Container>
    </footer>
  );
}
