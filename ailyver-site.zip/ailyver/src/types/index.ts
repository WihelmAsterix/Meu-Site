import type { LucideIcon } from "lucide-react";

export type Service = {
  id: string;
  icon: LucideIcon;
  title: string;
  description: string;
  highlights: string[];
};

export type ProcessStep = {
  number: string;
  title: string;
  description: string;
};

export type PricingPlan = {
  id: string;
  name: string;
  tagline: string;
  price: string;
  priceNote: string;
  featured?: boolean;
  features: string[];
};

export type PortfolioProject = {
  id: string;
  name: string;
  segment: string;
  description: string;
  technologies: string[];
  result: string;
  accent: string;
};

export type Testimonial = {
  id: string;
  name: string;
  role: string;
  company: string;
  segment: string;
  quote: string;
};

export type FaqItem = {
  id: string;
  question: string;
  answer: string;
};

export type Differential = {
  icon: LucideIcon;
  title: string;
  description: string;
};
