import type { PortfolioProject } from "@/types";

/**
 * Projetos demonstrativos — representam o padrão de qualidade da AiLyver
 * e devem ser substituídos por cases reais conforme a carteira de clientes crescer.
 */
export const portfolioProjects: PortfolioProject[] = [
  {
    id: "burger-house",
    name: "Burger House",
    segment: "Restaurante",
    description:
      "Experiência digital criada para aumentar pedidos e facilitar o acesso ao cardápio digital.",
    technologies: ["Next.js", "Cardápio digital", "WhatsApp"],
    result: "+38% em pedidos via WhatsApp no primeiro mês",
    accent: "from-neon/25",
  },
  {
    id: "padoca-do-bairro",
    name: "Padoca do Bairro",
    segment: "Padaria",
    description:
      "Site institucional com catálogo de produtos e encomendas facilitadas para datas especiais.",
    technologies: ["Next.js", "SEO local", "Google Maps"],
    result: "Presença consolidada no Google Meu Negócio",
    accent: "from-neon/20",
  },
  {
    id: "vigor-fit",
    name: "Vigor Fit",
    segment: "Academia",
    description:
      "Landing page de conversão para captação de novos alunos com agendamento de aula experimental.",
    technologies: ["Landing Page", "CRO", "Formulário inteligente"],
    result: "+52% em agendamentos de aula experimental",
    accent: "from-neon/25",
  },
  {
    id: "clinica-vitta",
    name: "Clínica Vitta",
    segment: "Clínica",
    description:
      "Experiência digital voltada à credibilidade médica, com agendamento online integrado.",
    technologies: ["Next.js", "Acessibilidade", "Agendamento"],
    result: "Redução de 40% em ligações para agendamento",
    accent: "from-neon/20",
  },
  {
    id: "corte-fino",
    name: "Corte Fino Barbearia",
    segment: "Barbearia",
    description:
      "Site moderno com identidade visual forte e agendamento direto pelo WhatsApp.",
    technologies: ["Next.js", "Identidade visual", "WhatsApp"],
    result: "Agenda cheia nas duas primeiras semanas",
    accent: "from-neon/25",
  },
  {
    id: "urbana-store",
    name: "Urbana Store",
    segment: "Loja",
    description:
      "Vitrine digital para loja de moda urbana com catálogo navegável e contato direto de vendas.",
    technologies: ["Next.js", "Catálogo", "Performance"],
    result: "Lighthouse 98 em performance mobile",
    accent: "from-neon/20",
  },
  {
    id: "imob-prime",
    name: "Imob Prime",
    segment: "Imobiliária",
    description:
      "Plataforma institucional com destaque para imóveis e captação de leads qualificados.",
    technologies: ["Next.js", "SEO", "Geração de leads"],
    result: "+61% em contatos qualificados",
    accent: "from-neon/25",
  },
  {
    id: "nexo-escritorio",
    name: "Nexo Escritório",
    segment: "Escritório de Serviços",
    description:
      "Presença institucional sofisticada para escritório de consultoria empresarial.",
    technologies: ["Next.js", "Design System", "Credibilidade"],
    result: "Autoridade digital reforçada junto a clientes B2B",
    accent: "from-neon/20",
  },
];
