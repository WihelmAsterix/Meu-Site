import {
  Code2,
  Rocket,
  ShoppingBag,
  Search,
  Gauge,
  Palette,
  Plug,
  ShieldCheck,
  Sparkles,
} from "lucide-react";
import type { Service } from "@/types";

export const services: Service[] = [
  {
    id: "desenvolvimento-web",
    icon: Code2,
    title: "Desenvolvimento Web",
    description:
      "Sites institucionais modernos, rápidos e personalizados, construídos com tecnologia de ponta.",
    highlights: ["Código sob medida", "Design exclusivo", "Escalável"],
  },
  {
    id: "landing-pages",
    icon: Rocket,
    title: "Landing Pages",
    description:
      "Páginas focadas em conversão, criadas para transformar visitantes em leads qualificados.",
    highlights: ["Foco em CRO", "Copy estratégica", "Alta performance"],
  },
  {
    id: "e-commerce",
    icon: ShoppingBag,
    title: "E-commerce",
    description:
      "Experiências digitais completas para empresas que vendem produtos e serviços pela internet.",
    highlights: ["Checkout otimizado", "Catálogo dinâmico", "Integrações de pagamento"],
  },
  {
    id: "seo",
    icon: Search,
    title: "SEO",
    description:
      "Estrutura técnica sólida para melhorar o posicionamento da sua empresa nos mecanismos de busca.",
    highlights: ["SEO técnico", "Dados estruturados", "Conteúdo otimizado"],
  },
  {
    id: "performance",
    icon: Gauge,
    title: "Performance",
    description:
      "Otimização de carregamento, Core Web Vitals e experiência de uso em qualquer dispositivo.",
    highlights: ["Carregamento instantâneo", "Core Web Vitals", "Menos JavaScript"],
  },
  {
    id: "identidade-digital",
    icon: Palette,
    title: "Identidade Digital",
    description:
      "Design alinhado à identidade visual da sua empresa, com consistência em todos os pontos de contato.",
    highlights: ["Design system", "Consistência visual", "Marca fortalecida"],
  },
  {
    id: "integracoes",
    icon: Plug,
    title: "Integrações",
    description:
      "WhatsApp, Google Maps, formulários, analytics e outras ferramentas conectadas ao seu site.",
    highlights: ["WhatsApp Business", "Google Maps", "Analytics"],
  },
  {
    id: "manutencao",
    icon: ShieldCheck,
    title: "Manutenção",
    description:
      "Atualizações, correções, segurança e evolução contínua para o seu projeto nunca ficar parado.",
    highlights: ["Atualizações", "Segurança", "Backups"],
  },
  {
    id: "inteligencia-artificial",
    icon: Sparkles,
    title: "Inteligência Artificial",
    description:
      "Automação e soluções inteligentes que aceleram processos e melhoram a experiência digital.",
    highlights: ["Automação", "Produtividade", "Processos inteligentes"],
  },
];
