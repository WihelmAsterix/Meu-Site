import type { ProcessStep } from "@/types";

export const processSteps: ProcessStep[] = [
  {
    number: "01",
    title: "Descoberta",
    description: "Entendemos o seu negócio, seu público e os objetivos por trás do projeto.",
  },
  {
    number: "02",
    title: "Estratégia",
    description: "Definimos estrutura, conteúdo e a experiência que o site precisa entregar.",
  },
  {
    number: "03",
    title: "Design",
    description: "Criamos a identidade visual da experiência, alinhada à sua marca.",
  },
  {
    number: "04",
    title: "Desenvolvimento",
    description: "Transformamos o design em um produto digital funcional e performático.",
  },
  {
    number: "05",
    title: "Testes",
    description: "Validamos responsividade, performance e funcionamento em todos os dispositivos.",
  },
  {
    number: "06",
    title: "Publicação",
    description: "Colocamos o projeto no ar, com toda a estrutura pronta para receber visitantes.",
  },
  {
    number: "07",
    title: "Evolução",
    description: "Mantemos e aprimoramos o projeto continuamente, junto com o seu negócio.",
  },
];
