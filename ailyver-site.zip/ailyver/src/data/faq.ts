import type { FaqItem } from "@/types";

export const faqItems: FaqItem[] = [
  {
    id: "custo",
    question: "Quanto custa criar um site?",
    answer:
      "O investimento varia conforme a complexidade do projeto. Trabalhamos com planos que vão de sites institucionais enxutos a experiências digitais completas. Consulte a seção de planos ou fale com a nossa equipe para um orçamento personalizado.",
  },
  {
    id: "prazo",
    question: "Quanto tempo demora?",
    answer:
      "Projetos mais simples costumam ficar prontos em poucas semanas. Projetos mais completos, com mais páginas e integrações, podem levar mais tempo. O prazo exato é definido na etapa de Descoberta, de acordo com o escopo do seu projeto.",
  },
  {
    id: "dominio",
    question: "O domínio está incluído?",
    answer:
      "O registro do domínio pode ser incluído no projeto ou gerenciado diretamente por você. Definimos isso juntos durante a etapa de estratégia, de acordo com a sua preferência.",
  },
  {
    id: "hospedagem",
    question: "A hospedagem está incluída?",
    answer:
      "Oferecemos planos de hospedagem e manutenção contínua para que seu site permaneça sempre no ar, seguro e atualizado. Também é possível utilizar uma hospedagem própria, caso já possua uma.",
  },
  {
    id: "mobile",
    question: "O site funciona no celular?",
    answer:
      "Sim. Todos os nossos projetos são desenvolvidos com responsividade total, priorizando a experiência em smartphones, já que a maior parte dos visitantes acessa por dispositivos móveis.",
  },
  {
    id: "manutencao",
    question: "Vocês fazem manutenção?",
    answer:
      "Sim. Oferecemos planos de manutenção contínua, incluindo atualizações, correções, segurança, backups e evolução do site conforme o seu negócio cresce.",
  },
  {
    id: "google",
    question: "O site aparece no Google?",
    answer:
      "Todos os projetos são desenvolvidos com boas práticas de SEO técnico desde a fundação. Isso melhora significativamente as chances de posicionamento, embora resultados em buscadores dependam de fatores contínuos de otimização e conteúdo.",
  },
  {
    id: "whatsapp",
    question: "Posso integrar WhatsApp?",
    answer:
      "Sim. A integração com WhatsApp é uma das mais solicitadas e já faz parte da maioria dos nossos projetos, facilitando o contato direto com potenciais clientes.",
  },
  {
    id: "alteracoes",
    question: "Posso solicitar alterações depois?",
    answer:
      "Sim. Além dos ajustes previstos durante o desenvolvimento, oferecemos planos de manutenção contínua para atualizações e evoluções futuras do seu site.",
  },
  {
    id: "cidades",
    question: "Vocês trabalham com empresas de qualquer cidade?",
    answer:
      "Sim. Atendemos negócios de todo o Brasil de forma 100% remota, com processos claros de comunicação em cada etapa do projeto.",
  },
  {
    id: "landing-page",
    question: "Posso contratar apenas uma landing page?",
    answer:
      "Sim. A landing page é uma das nossas soluções e pode ser contratada isoladamente, principalmente para campanhas específicas ou lançamentos.",
  },
  {
    id: "ia",
    question: "A AiLyver utiliza Inteligência Artificial?",
    answer:
      "Sim. Utilizamos Inteligência Artificial como ferramenta para acelerar o desenvolvimento e otimizar processos, mas a estratégia, o design e a engenharia continuam sendo conduzidos pela nossa equipe.",
  },
  {
    id: "crescimento",
    question: "O site pode crescer junto com minha empresa?",
    answer:
      "Sim. Construímos os projetos com uma arquitetura escalável, pensada para receber novas páginas, funcionalidades e integrações conforme o seu negócio evolui.",
  },
];
