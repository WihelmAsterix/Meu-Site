import type { Testimonial } from "@/types";

/**
 * Depoimentos demonstrativos, com estrutura pronta para substituição
 * por depoimentos reais de clientes.
 */
export const testimonials: Testimonial[] = [
  {
    id: "1",
    name: "Rafael Nogueira",
    role: "Proprietário",
    company: "Burger House",
    segment: "Restaurante",
    quote:
      "O site ficou muito acima do que eu esperava. Os pedidos pelo WhatsApp aumentaram e os clientes elogiam a experiência no celular.",
  },
  {
    id: "2",
    name: "Camila Duarte",
    role: "Diretora",
    company: "Clínica Vitta",
    segment: "Saúde",
    quote:
      "A equipe da AiLyver entendeu exatamente o que a clínica precisava transmitir: confiança. O resultado foi um site sério, rápido e profissional.",
  },
  {
    id: "3",
    name: "Bruno Alencar",
    role: "Fundador",
    company: "Vigor Fit",
    segment: "Academia",
    quote:
      "Desde que lançamos a nova landing page, o número de aulas experimentais agendadas praticamente dobrou. Processo transparente do início ao fim.",
  },
  {
    id: "4",
    name: "Larissa Prado",
    role: "Sócia",
    company: "Imob Prime",
    segment: "Imobiliária",
    quote:
      "Profissionalismo em cada etapa. O site comunica exatamente a seriedade que queríamos para a marca, e o suporte contínuo faz toda diferença.",
  },
];
