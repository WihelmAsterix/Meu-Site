import {
  Fingerprint,
  BrainCircuit,
  Terminal,
  Gauge,
  Search,
  Smartphone,
  Layers,
  LifeBuoy,
  Lock,
} from "lucide-react";
import type { Differential } from "@/types";

export const differentials: Differential[] = [
  {
    icon: Fingerprint,
    title: "Design personalizado",
    description: "Cada projeto nasce da identidade do seu negócio — nada de templates genéricos.",
  },
  {
    icon: BrainCircuit,
    title: "Desenvolvimento com IA",
    description: "Inteligência Artificial como acelerador de processos, guiada por profissionais.",
  },
  {
    icon: Terminal,
    title: "Código profissional",
    description: "Arquitetura limpa, escalável e sustentada pelas melhores práticas do mercado.",
  },
  {
    icon: Gauge,
    title: "Alta performance",
    description: "Sites rápidos, leves e otimizados para uma experiência impecável.",
  },
  {
    icon: Search,
    title: "SEO técnico",
    description: "Estrutura pensada desde o início para ser encontrada nos mecanismos de busca.",
  },
  {
    icon: Smartphone,
    title: "Responsividade real",
    description: "Experiência perfeita em qualquer tela, com prioridade máxima para o mobile.",
  },
  {
    icon: Layers,
    title: "Integração com ferramentas",
    description: "WhatsApp, Maps, formulários e analytics conectados ao seu fluxo comercial.",
  },
  {
    icon: LifeBuoy,
    title: "Suporte contínuo",
    description: "Acompanhamento após o lançamento, com manutenção e evolução constantes.",
  },
  {
    icon: Lock,
    title: "Segurança em primeiro lugar",
    description: "Boas práticas de segurança aplicadas em toda a estrutura do projeto.",
  },
];
