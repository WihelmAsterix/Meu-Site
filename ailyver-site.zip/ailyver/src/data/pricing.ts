import type { PricingPlan } from "@/types";

/**
 * Valores de referência — ajuste livremente conforme a estratégia comercial.
 * Mantidos em um único arquivo para facilitar futuras atualizações.
 */
export const pricingPlans: PricingPlan[] = [
  {
    id: "start",
    name: "Start",
    tagline: "Para pequenos negócios que precisam começar com o pé direito.",
    price: "A partir de R$ 1.490",
    priceNote: "projeto único",
    features: [
      "Site institucional de até 4 páginas",
      "Design responsivo personalizado",
      "Botão de WhatsApp integrado",
      "SEO básico configurado",
      "Formulário de contato",
      "1 rodada de ajustes",
    ],
  },
  {
    id: "business",
    name: "Business",
    tagline: "Para empresas que desejam uma presença digital mais completa.",
    price: "A partir de R$ 2.990",
    priceNote: "projeto único",
    featured: true,
    features: [
      "Site institucional de até 8 páginas",
      "Design exclusivo com animações",
      "SEO técnico avançado",
      "Integração com WhatsApp e Google Maps",
      "Formulários inteligentes",
      "Painel de conteúdo simplificado",
      "3 meses de suporte incluso",
    ],
  },
  {
    id: "premium",
    name: "Premium",
    tagline: "Para empresas que desejam uma experiência digital avançada.",
    price: "Sob consulta",
    priceNote: "projeto personalizado",
    features: [
      "Páginas ilimitadas",
      "Experiência digital sob medida",
      "Automação com Inteligência Artificial",
      "E-commerce ou área logada",
      "SEO técnico e estratégico completo",
      "Integrações avançadas",
      "Manutenção e evolução contínua",
    ],
  },
];
