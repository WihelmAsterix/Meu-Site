export type NavLink = {
  label: string;
  href: string;
};

export const mainNav: NavLink[] = [
  { label: "Início", href: "#inicio" },
  { label: "Soluções", href: "#solucoes" },
  { label: "Processo", href: "#processo" },
  { label: "Projetos", href: "#projetos" },
  { label: "Planos", href: "#planos" },
  { label: "FAQ", href: "#faq" },
  { label: "Contato", href: "#contato" },
];

export const footerNav: { title: string; links: NavLink[] }[] = [
  {
    title: "Empresa",
    links: [
      { label: "Início", href: "#inicio" },
      { label: "Diferenciais", href: "#diferenciais" },
      { label: "Tecnologia & IA", href: "#tecnologia" },
    ],
  },
  {
    title: "Soluções",
    links: [
      { label: "Serviços", href: "#solucoes" },
      { label: "Processo", href: "#processo" },
      { label: "Planos", href: "#planos" },
    ],
  },
  {
    title: "Suporte",
    links: [
      { label: "Projetos", href: "#projetos" },
      { label: "FAQ", href: "#faq" },
      { label: "Contato", href: "#contato" },
    ],
  },
];
