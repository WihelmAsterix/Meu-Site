/**
 * Configuração central da AiLyver.
 * Todas as informações institucionais ficam concentradas aqui para que
 * possam ser alteradas em um único lugar no futuro.
 */
export const siteConfig = {
  name: "AiLyver",
  legalName: "AiLyver Tecnologia e Presença Digital",
  slogan: "Presença digital extraordinária.",
  description:
    "A AiLyver cria sites, experiências digitais e soluções inteligentes que transformam negócios locais em marcas profissionais na internet.",
  url: "https://ailyver.com.br",
  locale: "pt_BR",

  contact: {
    whatsapp: "5511999999999", // Formato E.164 sem "+" — alterar para o número real
    whatsappDisplay: "+55 (11) 99999-9999",
    email: "contato@ailyver.com.br",
    instagram: "https://instagram.com/ailyver",
    linkedin: "https://linkedin.com/company/ailyver",
    address: "Atendimento remoto para todo o Brasil",
  },

  keywords: [
    "criação de sites",
    "desenvolvimento de sites",
    "agência digital",
    "criação de sites profissionais",
    "sites para empresas",
    "desenvolvimento web",
    "sites para pequenos negócios",
    "presença digital",
    "inteligência artificial",
    "automação digital",
    "landing page",
    "agência de tecnologia",
  ],

  logo: {
    icon: "/favicon.svg",
  },
} as const;

/** Monta o link direto para o WhatsApp com uma mensagem pré-definida. */
export function buildWhatsAppLink(message?: string) {
  const base = `https://wa.me/${siteConfig.contact.whatsapp}`;
  if (!message) return base;
  return `${base}?text=${encodeURIComponent(message)}`;
}
