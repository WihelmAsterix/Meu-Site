/**
 * Tokens de tema da AiLyver.
 * O vermelho neon é a única variável que precisa ser alterada para
 * atualizar a identidade visual de todo o site.
 */
export const themeConfig = {
  colors: {
    neon: "#FF0B3E",
    neonSoft: "#FF3B62",
    neonDim: "#B4092C",
    background: "#050505",
    backgroundDeep: "#020202",
    surface: "#101012",
    surfaceAlt: "#1A1A1D",
    border: "#26262A",
    textPrimary: "#F5F5F7",
    textSecondary: "#A1A1AA",
    textMuted: "#7A7A83",
  },
  radius: {
    sm: "0.5rem",
    md: "0.875rem",
    lg: "1.25rem",
    full: "9999px",
  },
  transitions: {
    fast: "180ms cubic-bezier(0.4, 0, 0.2, 1)",
    base: "320ms cubic-bezier(0.4, 0, 0.2, 1)",
    slow: "560ms cubic-bezier(0.16, 1, 0.3, 1)",
  },
  breakpoints: {
    sm: 480,
    md: 768,
    lg: 1024,
    xl: 1280,
    "2xl": 1536,
  },
} as const;
