/**
 * Configuração do Next.js.
 *
 * O projeto é exportado como um site 100% estático (output: "export"),
 * pronto para ser publicado no GitHub Pages através do workflow em
 * .github/workflows/deploy.yml.
 *
 * Se o repositório NÃO for publicado na raiz de um domínio (ex.:
 * usuario.github.io/ailyver), defina a variável de ambiente
 * NEXT_PUBLIC_BASE_PATH com o nome do repositório (ex.: "/ailyver").
 * O workflow de deploy já faz isso automaticamente.
 */
const basePath = process.env.NEXT_PUBLIC_BASE_PATH || "";

/** @type {import('next').NextConfig} */
const nextConfig = {
  output: "export",
  basePath,
  assetPrefix: basePath ? `${basePath}/` : undefined,
  trailingSlash: true,
  images: {
    unoptimized: true,
  },
  reactStrictMode: true,
};

export default nextConfig;
