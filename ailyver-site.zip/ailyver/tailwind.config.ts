import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./src/app/**/*.{ts,tsx}",
    "./src/components/**/*.{ts,tsx}",
    "./src/data/**/*.{ts,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        neon: {
          DEFAULT: "#FF0B3E",
          soft: "#FF3B62",
          dim: "#B4092C",
        },
        ink: {
          950: "#020202",
          900: "#050505",
          850: "#0A0A0B",
          800: "#101012",
          700: "#1A1A1D",
          600: "#26262A",
        },
        mist: {
          400: "#7A7A83",
          300: "#A1A1AA",
          200: "#C7C7CF",
          100: "#EDEDF0",
        },
      },
      fontFamily: {
        display: ["var(--font-display)", "Segoe UI", "system-ui", "sans-serif"],
        body: ["var(--font-body)", "Segoe UI", "system-ui", "sans-serif"],
        mono: ["var(--font-mono)", "ui-monospace", "SF Mono", "monospace"],
      },
      backgroundImage: {
        "grid-fade":
          "linear-gradient(to bottom, transparent, rgba(2,2,2,0.9)), repeating-linear-gradient(0deg, rgba(255,11,62,0.06) 0px, rgba(255,11,62,0.06) 1px, transparent 1px, transparent 64px), repeating-linear-gradient(90deg, rgba(255,11,62,0.06) 0px, rgba(255,11,62,0.06) 1px, transparent 1px, transparent 64px)",
        "radial-glow":
          "radial-gradient(circle at 50% 0%, rgba(255,11,62,0.22), transparent 60%)",
      },
      boxShadow: {
        neon: "0 0 0 1px rgba(255,11,62,0.4), 0 0 24px rgba(255,11,62,0.35), 0 0 60px rgba(255,11,62,0.15)",
        "neon-sm": "0 0 0 1px rgba(255,11,62,0.35), 0 0 12px rgba(255,11,62,0.3)",
        card: "0 1px 0 0 rgba(255,255,255,0.04) inset, 0 20px 60px -30px rgba(0,0,0,0.9)",
      },
      borderRadius: {
        xl2: "1.25rem",
      },
      keyframes: {
        float: {
          "0%, 100%": { transform: "translateY(0px)" },
          "50%": { transform: "translateY(-14px)" },
        },
        "pulse-glow": {
          "0%, 100%": { opacity: "0.55" },
          "50%": { opacity: "1" },
        },
        marquee: {
          "0%": { transform: "translateX(0)" },
          "100%": { transform: "translateX(-50%)" },
        },
      },
      animation: {
        float: "float 6s ease-in-out infinite",
        "pulse-glow": "pulse-glow 3.5s ease-in-out infinite",
        marquee: "marquee 28s linear infinite",
      },
    },
  },
  plugins: [],
};

export default config;
